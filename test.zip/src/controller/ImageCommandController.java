package controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.function.Function;

import controller.commands.Blur;
import controller.commands.Brighten;
import controller.commands.Combine;
import controller.commands.Dither;
import controller.commands.Flip;
import controller.commands.Greyscale;
import controller.commands.Load;
import controller.commands.Save;
import controller.commands.Sepia;
import controller.commands.Sharpen;
import controller.commands.Split;
import model.ImageProcessor;
import utility.IImageHelperFactory;
import view.IView;

/**
 * This class represents a controller that interprets a set of commands to manipulate images and
 * take the appropriate action.
 */
public class ImageCommandController implements CommandController {
  private final ImageProcessor model;
  private InputStream inputStream;
  private final IView view;
  private final Map<String, Function<Scanner, ImageOperationCommand>> supportedOperations;
  private final IImageHelperFactory imageHelperFactory;

  /**
   * Initialises a controller object with the given model, view, input stream and helper factory.
   *
   * @param model              the model that performs the various image manipulations
   * @param in                 the input stream
   * @param view               the view
   * @param imageHelperFactory the factory class that provides the utility class based on the
   *                           image type that is to be modified
   */
  public ImageCommandController(ImageProcessor model, InputStream in, IView view,
                                IImageHelperFactory imageHelperFactory) {
    this.model = model;
    this.inputStream = in;
    this.view = view;
    this.imageHelperFactory = imageHelperFactory;
    // add the supported operations to the map
    this.supportedOperations = new HashMap<>();
    this.supportedOperations.put("load", (Scanner sc) -> {
      ImageOperationCommand command = new Load(sc.next(), sc.next(), this.imageHelperFactory);
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("brighten", (Scanner sc) -> {
      ImageOperationCommand command = new Brighten(sc.nextInt(), sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("rgb-combine", (Scanner sc) -> {
      ImageOperationCommand command = new Combine(sc.next(), sc.next(), sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("vertical-flip", (Scanner sc) -> {
      ImageOperationCommand command = new Flip(sc.next(), sc.next(), 1);
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("horizontal-flip", (Scanner sc) -> {
      ImageOperationCommand command = new Flip(sc.next(), sc.next(), 0);
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("greyscale", (Scanner sc) -> {
      String parameter1 = sc.next();
      String parameter2 = sc.next();
      ImageOperationCommand command;
      if (sc.hasNext()) {
        command = new Greyscale(parameter1, parameter2, sc.next());
      } else {
        command = new Greyscale(parameter1, parameter2);
      }
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("rgb-split", (Scanner sc) -> {
      ImageOperationCommand command = new Split(sc.next(), sc.next(), sc.next(),
              sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("save", (Scanner sc) -> {
      ImageOperationCommand command = new Save(sc.next(), sc.next(), this.imageHelperFactory);
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("sepia", (Scanner sc) -> {
      ImageOperationCommand command = new Sepia(sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("dither", (Scanner sc) -> {
      ImageOperationCommand command = new Dither(sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("blur", (Scanner sc) -> {
      ImageOperationCommand command = new Blur(sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });

    this.supportedOperations.put("sharpen", (Scanner sc) -> {
      ImageOperationCommand command = new Sharpen(sc.next(), sc.next());
      if (sc.hasNext()) {
        throw new IllegalArgumentException("Invalid command format");
      }
      return command;
    });
  }

  @Override
  public void process() {
    Scanner scanner = new Scanner(this.inputStream);
    StringBuilder builder = new StringBuilder();
    String commandStatus;
    // Read from the input stream
    while (scanner.hasNextLine()) {
      String line = scanner.nextLine();
      if (!line.isEmpty() && line.charAt(0) != '#') {
        // tokenize the line and check for the command, throw an error if it's an invalid command
        String[] tokens = line.trim().split("\\s+");
        String command = tokens[0];
        if (command.equals("quit")) {
          System.exit(0);
        }
        // empty the buffer and append the rest of the current user input to the buffer
        builder.setLength(0);
        for (int i = 1; i < tokens.length; i++) {
          builder.append(tokens[i]).append(System.lineSeparator());
        }
        try {
          // Execute the command
          commandStatus = processCommand(command, new Scanner(builder.toString()));
          view.print(commandStatus);
        } catch (NoSuchElementException | UnsupportedOperationException
                 | IllegalArgumentException ex) {
          if (ex.getMessage() == null) {
            view.print("Invalid command format");
          } else {
            view.print(ex.getMessage());
          }
        } catch (RuntimeException ex) {
          view.print(ex.getMessage());
        }
      }
    }
  }

  /**
   * Executes the given command with the given input via the scanner.
   *
   * @param command the command to execute
   * @param sc      the scanner object with the input to process
   * @return the output on executing the command
   * @throws UnsupportedOperationException if the given command is not supported
   * @throws NoSuchElementException        if the given command does not contain all the required
   *                                       input to execute the command
   * @throws IllegalArgumentException      if the given command contains invalid inputs
   */
  private String processCommand(String command, Scanner sc) throws UnsupportedOperationException,
          NoSuchElementException, IllegalArgumentException {
    StringBuilder output = new StringBuilder();
    if (command.equals("run")) {
      try {
        String fileName = sc.next();
        if (sc.hasNext()) {
          throw new IllegalArgumentException("Invalid command format");
        }
        // If the command is to run a script file, call the go method of the controller with a
        // different input stream
        this.inputStream = new FileInputStream(fileName);
        this.process();
      } catch (FileNotFoundException ex) {
        output.append("Script file not found");
      }
    } else {
      Function<Scanner, ImageOperationCommand> commandToExecute =
              this.supportedOperations.getOrDefault(command, null);
      if (commandToExecute == null) {
        throw new UnsupportedOperationException("Invalid command");
      }
      commandToExecute.apply(sc).execute(this.model);
      output.append("Executed command: ").append(command);
    }
    return output.toString();
  }
}

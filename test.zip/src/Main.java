import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import controller.ImageCommandController;
import model.ImageProcessor;
import model.ImageProcessorImpl;
import utility.ImageHelperFactory;
import view.IView;
import view.View;

/**
 * This is main class. This class represents the entry point of the program.
 */
public class Main {
  /**
   * It creates a model, view and controller object,
   * then passes the control to the controller.
   */
  public static void main(String[] args) {
    // Create the model object and view object to pass to the controller
    // If a script file is passed via command line arguments, pass the script file as the source
    // of the commands.
    ImageProcessor model = new ImageProcessorImpl();
    IView view = new View(System.out);
    if (args.length > 0) {
      if (args[0].equals("-file") && args.length > 1) {
        try {
          handOver(model, new FileInputStream(args[1]), view);
        } catch (FileNotFoundException e) {
          System.out.println("Invalid file");
        }
      } else {
        System.out.println("Invalid arguments");
      }
      System.exit(0);
    }
    handOver(model, System.in, view);
  }

  private static void handOver(ImageProcessor model, InputStream in, IView view) {
    ImageCommandController controller = new ImageCommandController(model, in, view,
            ImageHelperFactory.getInstance());
    controller.process();
  }
}
package utility;

import java.util.Arrays;

/**
 * This class represents an image. Each image is identified by a name and,
 * a 2D array of Pixel that contains the actual data of the image.
 */
public class CustomImage {
  private final String name;
  private final Pixel[][] pixels;
  private final int maxPixelValue;

  /**
   * Constructs a Custom Image with the given name and 2D array of Pixel.
   *
   * @param name          is the name used to identify the CustomImage
   * @param pixels        the actual pixel values of the image
   * @param maxPixelValue the maximum value a channel of the Pixel can have
   */
  public CustomImage(String name, Pixel[][] pixels, int maxPixelValue) {
    this.name = name;
    this.pixels = pixels;
    this.maxPixelValue = maxPixelValue;
  }

  /**
   * Returns the height of the image.
   *
   * @return height of image
   */
  public int getHeight() {
    return this.pixels.length;
  }

  /**
   * Returns the width of the image.
   *
   * @return width of the image.
   */
  public int getWidth() {
    return this.pixels[0].length;
  }

  /**
   * Returns the max value that a channel of the Pixel can have.
   *
   * @return max value of a channel of Pixel.
   */
  public int getMaxPixelValue() {
    return this.maxPixelValue;
  }

  /**
   * Returns the Pixel at the given position from the 2D array.
   *
   * @param row the row index
   * @param col the col index
   * @return the Pixel at the given row and col.
   */
  public Pixel getPixel(int row, int col) {
    if (row >= this.getHeight() || col >= this.getWidth()) {
      throw new IllegalArgumentException("The row and col position exceeds "
              + "the height and width of the image.");
    }
    return this.pixels[row][col];
  }

  /**
   * Returns the name of the CustomImage.
   *
   * @return the name of the image.
   */
  public String getName() {
    return this.name;
  }

  /**
   * Compares if two CustomImage objects are equal. Two CustomImage Objects are equal if they have,
   * the same width, height and, pixel values at each position in the 2D array of Pixels
   *
   * @param o Object to be compares with {@code this}
   * @return boolean value after comparing the two objects.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (!(o instanceof CustomImage)) {
      return false;
    }
    CustomImage img2 = (CustomImage) o;

    if (this.getWidth() == img2.getWidth() && this.getHeight() == img2.getHeight()) {
      for (int x = 0; x < this.getHeight(); x++) {
        for (int y = 0; y < this.getWidth(); y++) {
          if (!this.getPixel(x, y).equals(img2.getPixel(x, y))) {
            return false;
          }
        }
      }
    } else {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    return Arrays.deepHashCode(this.pixels) * this.name.hashCode();
  }
}

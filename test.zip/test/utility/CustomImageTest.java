package utility;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * A Junit test class for the CustomImage.
 */
public class CustomImageTest {

  private static final int MAX_PIXEL_VALUE = 255;

  private final Pixel red = new Pixel(255, 0, 0, 255);
  private final Pixel green = new Pixel(0, 255, 0, 255);
  private final Pixel blue = new Pixel(0, 0, 255, 255);
  private final Pixel black = new Pixel(0, 0, 0, 255);
  private final Pixel orange = new Pixel(255, 153, 51, 255);
  private final Pixel white = new Pixel(255, 255, 255, 255);

  private final CustomImage expectedImg = new CustomImage("expected_base", new Pixel[][]{
          {red, green, blue},
          {black, orange, white}
  }, MAX_PIXEL_VALUE);


  @Test
  public void testConstructor() {
    CustomImage baseImg = new CustomImage("base", new Pixel[][]{
            {red, green, blue},
            {black, orange, white}
    }, MAX_PIXEL_VALUE);
    assertEquals("base", baseImg.getName());
    assertEquals(MAX_PIXEL_VALUE, baseImg.getMaxPixelValue());
    assertEquals(3, baseImg.getWidth());
    assertEquals(2, baseImg.getHeight());
    for (int x = 0; x < baseImg.getHeight(); x++) {
      for (int y = 0; y < baseImg.getWidth(); y++) {
        assertEquals(baseImg.getPixel(x, y), expectedImg.getPixel(x, y));
      }
    }
    assertEquals(baseImg, expectedImg);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetPixelWithInvalidRow() {
    expectedImg.getPixel(5, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetPixelWithInvalidCol() {
    expectedImg.getPixel(1, 5);
  }

}